@extends('layouts.main.master')

@section('content')
    <h1>content</h1>
@endsection