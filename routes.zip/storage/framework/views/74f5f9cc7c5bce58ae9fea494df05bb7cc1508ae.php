<?php $__env->startSection('title'); ?>
Profile
<?php $__env->stopSection(); ?>

<?php $__env->startSection('csslink'); ?>
  <link href="<?php echo e(asset('admin/js/plugins/prism/prism.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="<?php echo e(asset('admin/js/plugins/perfect-scrollbar/perfect-scrollbar.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="<?php echo e(asset('admin/js/plugins/chartist-js/chartist.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
   
  <link href="<?php echo e(asset('admin/js/plugins/animate-css/animate.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
   
  <link href="<?php echo e(asset('admin/js/plugins/dropify/css/dropify.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">

  <style type="text/css"> 
    .select-wrapper {
          position: relative;
          margin-left: 45px;
      }
  </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
      <!-- START CONTENT -->
      <section id="content">        

        <!--start container-->
        <div class="container">
          <!-- profile-page Start-->
          <div id="profile-page" class="section">

          
              <?php if(session('success')): ?>
                <div id="card-alert" class="card green">
                      <div class="card-content white-text">
                        <p><i class="mdi-navigation-check"></i> <?php echo e(session('success')); ?></p>
                      </div>
                      <button type="button" class="close white-text" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
               </div>
              <?php endif; ?>
           

           
            <!-- profile-page-header -->
            <div id="profile-page-header" class="card">
                <div class="card-image waves-effect waves-block waves-light">
                    <img class="activator" src="<?php echo e(asset('admin/images/user-profile-bg.jpg')); ?>" alt="user background">                    
                </div>
                <figure class="card-profile-image">
          <img src="/doctors/avatar/<?php echo e($doctor->avatar); ?>" alt="profile image" class="circle z-depth-2 responsive-img activator"/>
                </figure>
                <div class="card-content">
                  <div class="row">                    
                    <div class="col s9 offset-s2">                        
                        <h4 class="card-title grey-text text-darken-4"><?php echo e($doctor->name); ?></h4>
                        <p class="medium-small grey-text"><?php echo e($doctor->Designation); ?>,&nbsp;Dept. of <?php echo e($doctor->Department); ?>,&nbsp;<?php echo e($doctor->HospitalName); ?></p> 
                                    
                    </div>
                                      
                    <div class="col s1 right-align">
                      <a class="btn-floating activator waves-effect waves-light darken-2 right">
                          <i class="mdi-action-perm-identity"></i>
                      </a>
                    </div>
                  </div>
                </div>
                <div class="card-reveal">
                    <p>
                      <span class="card-title grey-text text-darken-4"><?php echo e($doctor->name); ?><i class="mdi-navigation-close right"></i></span>
                    </p>

                    <p>
                      <i class="mdi-action-perm-identity cyan-text text-darken-2"></i><?php echo e($doctor->Designation); ?>,&nbsp;Dept. of <?php echo e($doctor->Department); ?>, &nbsp; <?php echo e($doctor->HospitalName); ?>

                    </p>
                    <p><?php echo e($doctor->Speciality); ?></p>
                    
                    <p><i class="mdi-action-perm-phone-msg cyan-text text-darken-2"></i> +88 <?php echo e($doctor->MobileNumber); ?>/p>
                    <p><i class="mdi-communication-email cyan-text text-darken-2"></i><?php echo e($doctor->email); ?></p>
                </div>
            </div>
            <!--/ profile-page-header Stop-->

            <!-- profile-page-content Start-->
            <div id="profile-page-content" class="row">

              <!-- profile-page-wall Start -->
              <div id="profile-page-wall" class="col s12 m12">
                <!-- profile-page-wall-share start -->
                <div id="profile-page-wall-share" class="row">
                  <div class="col s12">
                    <ul class="tabs tab-profile z-depth-1 light-blue">
                      <li class="tab col s3"><a class="white-text waves-effect waves-light active" href="#PersonalInfo"><i class="mdi-editor-border-color"></i>Personal Information</a>
                      </li>
                      
                                           
                    </ul>
                    <form method="POST" enctype="multipart/form-data" action="<?php echo e(Route('profileUpdate')); ?>" >
                     <?php echo e(csrf_field()); ?>

                      <div class="card-panel">
                       <div class="row">
                        <div class="col s12">
                          <!-- Personal Information-->
                          <div id="PersonalInfo" class="tab-content col s12">
                            <h4 class="header2">Personal Information</h4>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-action-account-circle prefix"></i>
                                  <input type="text" 
                                         name="txt_FullName" 
                                         value="<?php echo e($doctor->name); ?>" 
                                         class="validate">
                                  <label>Full Name</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-maps-local-hospital prefix"></i>
                                  <input type="text" 
                                         name="txt_Username" 
                                         value="<?php echo e($doctor->username); ?>" 
                                         class="validate"
                                         disabled />
                                  <label>Username ( Username is not changeable. )</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-communication-call prefix"></i>
                                  <input type="text" 
                                         name="txt_MobileNumber" 
                                         value="<?php echo e($doctor->mobile_number); ?>" 
                                         class="validate">
                                  <label>Mobile Number</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-editor-border-color prefix"></i>
                                  <input type="text" 
                                         name="txt_Designation" 
                                         value="<?php echo e($doctor->designation); ?>" 
                                         class="validate">
                                  <label>Designation</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-editor-border-color prefix"></i>
                                  <input type="text" 
                                         name="txt_JobTitle" 
                                         value="<?php echo e($doctor->job_title); ?>" 
                                         class="validate">
                                  <label>Job Title</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-action-stars prefix"></i>
                                  <input type="text" 
                                         name="txt_Degrees" 
                                         value="<?php echo e($doctor->degrees); ?>" 
                                         class="validate">
                                  <label>Degrees</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-action-account-balance prefix"></i>
                                  <input type="text" 
                                         name="txt_BMDC" 
                                         value="<?php echo e($doctor->bmdc_number); ?>" 
                                         class="validate">
                                  <label>BMDC Reg. No</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-action-grade prefix"></i>
                                  <input type="text" 
                                         name="txt_Department" 
                                         value="<?php echo e($doctor->department); ?>" 
                                         class="validate">
                                  <label>Department of</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-action-bookmark prefix"></i>
                                  <input type="text" 
                                         name="txt_Specialty" 
                                         value="<?php echo e($doctor->speciality); ?>" 
                                         class="validate">
                                  <label>Specialty</label>
                                </div>
                              </div>

                              

                              <div class="row">
                                <div class="input-field col s12">
                                   <i class="mdi-maps-place prefix"></i>
                                      <select name="opt_City">
                                        <option value="City">City</option>
                                        <option  
                                        <?php echo e($doctor->city===('Dhaka') ? 'selected' : ''); ?>

                                        value="Dhaka">Dhaka</option>

                                        <option  
                                        <?php echo e($doctor->city===('Narayanganj') ? 'selected' : ''); ?>

                                        value="Narayanganj">Narayanganj</option>

                                        <option  
                                        <?php echo e($doctor->city===('Chittaogng') ? 'selected' : ''); ?>

                                        value="Chittaogng">Chittaogng</option>

                                        <option  
                                        <?php echo e($doctor->city===('Khulna') ? 'selected' : ''); ?>

                                        value="Khulna">Khulna</option>

                                        <option  
                                        <?php echo e($doctor->city===('Bogra') ? 'selected' : ''); ?>

                                        value="Bogra">Bogra</option>

                                        <option  
                                        <?php echo e($doctor->city===('Mymensingh') ? 'selected' : ''); ?>

                                        value="Mymensingh">Mymensingh</option>

                                        <option  
                                        <?php echo e($doctor->city===('Rajshahi') ? 'selected' : ''); ?>

                                        value="Rajshahi">Rajshahi</option>

                                        <option  
                                        <?php echo e($doctor->city===('Sylhet') ? 'selected' : ''); ?>

                                        value="Sylhet">Sylhet</option>

                                        <option  
                                        <?php echo e($doctor->city===('Comilla') ? 'selected' : ''); ?>

                                        value="Comilla">Comilla</option>

                                        <option  
                                        <?php echo e($doctor->city===('Kishorganj') ? 'selected' : ''); ?>

                                        value="Kishorganj">Kishorganj</option>

                                        <option  
                                        <?php echo e($doctor->city===('Natore') ? 'selected' : ''); ?>

                                        value="Natore">Natore</option>

                                        <option  
                                        <?php echo e($doctor->city===('Tangail') ? 'selected' : ''); ?>

                                        value="Tangail">Tangail</option>

                                        <option  
                                        <?php echo e($doctor->city===('Barisal') ? 'selected' : ''); ?>

                                        value="Barisal">Barisal</option>

                                      </select>
                                     <label>City</label>
                                </div>
                               </div>

                                <div class="row">
                                <div class="input-field col s12">
                                   <i class="mdi-maps-pin-drop prefix"></i>
                                      <select name="opt_SubArea">
                                        <option  value="SubArea">Sub Area</option>

                                        <option
                                        <?php echo e($doctor->subarea===('Uttra') ? 'selected' : ''); ?> 
                                         value="Uttra">Uttra</option>

                                         <option
                                        <?php echo e($doctor->subarea===('Demra') ? 'selected' : ''); ?> 
                                         value="Demra">Demra</option>

                                         <option
                                        <?php echo e($doctor->subarea===('Badda') ? 'selected' : ''); ?> 
                                         value="Badda">Badda</option>

                                      </select>
                                     <label>Sub Area</label>
                                </div>
                              </div>
                              
                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-maps-navigation prefix"></i>
                                  <textarea class="materialize-textarea" 
                                            name="txt_WorkingAddress"><?php echo e($doctor->working_address); ?></textarea>
                                  <label for="Address">Working Address</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-maps-local-hospital prefix"></i>
                                  <input type="text" 
                                         name="txt_HospitalName" 
                                         value="<?php echo e($doctor->hospital_name); ?>" 
                                         class="validate">
                                  <label>Hospital Name</label>
                                </div>
                              </div>
                              
                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-social-group-add prefix"></i>
                                  <input type="text" 
                                         name="txt_Association" 
                                         value="<?php echo e($doctor->association); ?>">
                                  <label for="Association">Association</label>
                                </div>
                              </div>
                              
                              <div class="row">
                                <div class="input-field col s12">
                                   <i class="mdi-action-accessibility prefix"></i>
                                   <select name="opt_Gender">
                                        <option  value="Gender">Gender</option>
                                        <option
                                        <?php echo e($doctor->gender===('Male') ? 'selected' : ''); ?>

                                         value="Male">Male</option>

                                         <option
                                        <?php echo e($doctor->gender===('Female') ? 'selected' : ''); ?>

                                         value="Female">Female</option>
                                      </select>
                                   <label>Gender</label>
                                </div>
                              </div> 

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-social-cake prefix"></i>
                                  <input type="date" 
                                         class="datepicker" 
                                         name="dat_DateofBirth" 
                                         value="<?php echo e($doctor->date_of_birth); ?>">
                                  <label>Date of Birth</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                   <i class="mdi-maps-local-florist prefix"></i>
                                      
                                      <select name="opt_Religion">
                                        <option  value="Religion">Religion</option>
                                        <option
                                        <?php echo e($doctor->religion===('Islam') ? 'selected' : ''); ?>

                                         value="Islam">Islam</option>
                                        <option  
                                        <?php echo e($doctor->religion===('Hindu') ? 'selected' : ''); ?>

                                        value="Hindu">Hindu</option>
                                      </select>
                                     <label>Religion</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <i class="mdi-action-receipt prefix"></i>
                                  <textarea class="materialize-textarea validate" 
                                            name="txt_DoctorShortSummery"><?php echo e($doctor->doctor_short_summery); ?></textarea>
                                  <label>Doctor Short Summery</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                   <i class="mdi-social-mood prefix"></i>
                                  <input type="text"
                                         disabled 
                                         value="Change your profile picture" 
                                         class="validate">
                                  <label>Avater</label>
                                </div>
                              </div>

                              <div class="row">
                                <div class="input-field col s12">
                                  <input type="file" 
                                         id="input-file-now"
                                         name="avatar" 
                                         class="dropify" 
                                         data-default-file="" />
                                </div>
                              </div>

                           </div>
 
                          
                          
                          
                         

                           
                          

                          <div class="row">
                            <div class="input-field col s12">
                              <button type="submit" 
                                      class="btn waves-effect waves-light light-blue accent-3 animated infinite rubberBand">
                                      Update
                                <i class="mdi-content-send right"></i>
                           </button>
                         </div>
                        </div>
                       </div> 
                      </div>
                     </div>
                    </form>
                  </div>

                </div>
                <!-- profile-page-wall-share Stop -->
               
              </div>
              <!--/ profile-page-wall Stop-->

            </div>
            <!-- profile-page-content Stop-->

          </div>
          <!-- profile-page Stop-->
        </div>
        
        <!--end container-->
      </section>
      <!-- END CONTENT -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('jslink'); ?>
  <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/prism/prism.js')); ?>"></script>
     
  <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/dropify/js/dropify.min.js')); ?>"></script>
  <script>
      $('.datepicker').pickadate({
    // Escape any “rule” characters with an exclamation mark (!).
    format: 'yyyy/mm/dd',
    formatSubmit: 'yyyy/mm/dd',
    hiddenPrefix: 'prefix__',
    hiddenSuffix: '__suffix'
  })   
  </script>
   <script type="text/javascript">
        $(document).ready(function(){
            // Basic
            $('.dropify').dropify();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.doctor.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>