<h1>Hello</h1>

<p>
	Please Click the following link to activate your account,
	<a href="<?php echo e(env('APP_URL')); ?>/activation/<?php echo e($user->email); ?>/<?php echo e($code); ?>">
		Activate account :)
	</a>
</p>

