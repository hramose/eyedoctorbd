<?php $__env->startSection('title'); ?>
	<title>All Doctors</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('csslink'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="pagetop">
	<div class="container">
		<span>What We Actually Do?</span>
		<h1><span>MEDICALIST</span> SURGEONS</h1>
		<ul>
			<li><a href="index-2.html" title="">Home</a></li>
			<li>Staff</li>
		</ul>
	</div>
</div>


<section>
	<div class="block">
		<div class="container">
			<div class="row">
				<div class="col column s12 m12 l12">
				<div class="all-surgeons">
					<div class="row">
						<div id="test-list"> 
							<div class="list">
							<?php $__currentLoopData = $allDoctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allDoctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="name col s12 m6 l3">
									<div class="surgeon">
										<a href="profile/<?php echo e($allDoctor->username); ?>" title="">
											<img src="/doctors/thumb/<?php echo e($allDoctor->avatar); ?>" alt="profile image"/>
											<div class="surgeon-info">
												<div class="surgeon-name">
													<h3><?php echo e($allDoctor->name); ?></h3>
												<span><?php echo e($allDoctor->designation); ?></span>
											</div>
										  </div>
										</a>
									</div><!-- Surgeon -->
								</div>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

							 </div>
								<ul class="pagination theme-pagi">

								<?php echo e($allDoctors->links()); ?>

									
								</ul><!-- Pagination -->	
						 </div>

						</div>
					</div><!-- All Surgeons -->
									
				</div>
			</div>
		</div>
	</div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jslink'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>