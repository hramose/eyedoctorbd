<?php $__env->startSection('content'); ?>
    <h1>content</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>