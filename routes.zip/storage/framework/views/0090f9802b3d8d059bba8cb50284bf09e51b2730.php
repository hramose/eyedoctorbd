<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="description" content="Materialize is a Material Design Admin Template,It's modern, responsive and based on Material Design by Google. ">
    <meta name="keywords" content="materialize, admin template, dashboard template, flat admin template, responsive admin template,">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Favicons-->
    <link rel="icon" href="<?php echo e(asset('admin/images/favicon/favicon-32x32.png')); ?>" sizes="32x32">
    <!-- Favicons-->
    <link rel="apple-touch-icon-precomposed" href="<?php echo e(asset('admin/images/favicon/apple-touch-icon-152x152.png')); ?>">
    <!-- For iPhone -->
    <meta name="msapplication-TileColor" content="#00bcd4">
    <meta name="msapplication-TileImage" content="<?php echo e(asset('admin/images/favicon/mstile-144x144.png')); ?>">
    <!-- For Windows Phone -->

    <!-- CORE CSS-->    
    <link href="<?php echo e(asset('admin/css/materialize.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
    <link href="<?php echo e(asset('admin/css/style.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
        
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/sweetalert.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
    <!-- Custome CSS-->    
    <link href="<?php echo e(asset('admin/css/custom/custom.min.css')); ?>" type="text/css" rel="stylesheet" media="screen,projection">
        
    <?php echo $__env->yieldContent('csslink'); ?>
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
</head>
<body>
    <?php echo $__env->make('layouts.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  <!-- START MAIN -->
  <div id="main">
    <!-- START WRAPPER -->
    <div class="wrapper">
    <?php echo $__env->make('layouts.admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
        <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- END WRAPPER -->
     </div>
    <!-- END MAIN -->
    <?php echo $__env->make('layouts.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- jQuery Library -->
    <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/jquery-1.11.2.min.js')); ?>"></script> 
        <!--materialize js-->
    <script type="text/javascript" src="<?php echo e(asset('admin/js/materialize.min.js')); ?>"></script>
     <!--scrollbar-->
    <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>

    <!-- sparkline -->
    <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins/sparkline/sparkline-script.js')); ?>"></script>
        <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="<?php echo e(asset('admin/js/plugins.min.js')); ?>"></script>
        
    <script src="<?php echo e(asset('admin/js/sweetalert-dev.js')); ?>"></script>
    <script type="text/javascript" src="//cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="<?php echo e(asset('admin/js/custom-script.js')); ?>"></script>
    <?php echo $__env->yieldContent('jslink'); ?>
</body>
</html>