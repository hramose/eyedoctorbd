<footer>
	
</footer>

<div class="bottom-footer">
	<div class="container">
		<p>© 2017 Eye Doctor BD All rights reserved. <i class="fa fa-code" aria-hidden="true"></i> with  <i class="fa fa-heart" aria-hidden="true"></i> by <a href="#" title="">i-SOFT</a> </p>
		<ul>
			<li><a href="#" title="">Blog</a></li>
			<li><a href="service.html" title="">Privacy policy</a></li>
			<li><a href="appointment.html" title="">FAQ</a></li>
			<li><a href="<?php echo e(route('contactus')); ?>" title="">Contact Us</a></li>
			<li><a href="#" title=""> About Us</a></li>
		</ul>
	</div>
</div>