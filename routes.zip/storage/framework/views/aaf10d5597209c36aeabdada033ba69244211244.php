<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <?php echo $__env->yieldContent('title'); ?>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel='shortcut icon' type='image/x-icon' href='<?php echo e(asset('images/favicon.ico')); ?>' / >

    <!-- Styles -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/materialize.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/color.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/alert.css')); ?>" />
    

    
    <?php echo $__env->yieldContent('csslink'); ?>
 
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
    
</head> 
<body>
<div class="theme-layout">
    <?php echo $__env->make('layouts.main.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('layouts.main.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>



    <script type="text/javascript" src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/materialize.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/enscroll-0.5.2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.poptrox.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/smoothscroll.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/script.js')); ?>"></script>

    
    <?php echo $__env->yieldContent('jslink'); ?>

</body>
</html>
