<?php $__env->startSection('title'); ?>
	<title><?php echo e($doctor->name); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('csslink'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section>
	<div class="block" style="padding: 50px 0;">
		<div class="container">
			<div class="row">
				<div class="col column s12 m12 l12">
					<div class="staff-detail">
						<div class="member-introduction">
							<div class="member-wrapper">
								<div class="staff-img"><img src="/doctors/profile/<?php echo e($doctor->avatar); ?>" alt="" /></div>
								<div class="member-detail">
									<i>Hello</i>
									<h2>I' m <strong><?php echo e($doctor->name); ?></strong></h2>
									<span><?php echo e($doctor->designation); ?>, Dept. of <?php echo e($doctor->department); ?>, <?php echo e($doctor->hospital_name); ?></span>
									<strong><?php echo e($doctor->designation); ?>, Dept. of <?php echo e($doctor->department); ?>, <?php echo e($doctor->hospital_name); ?></strong>
									<ul class="info-list">
										<li><strong>Address:</strong>24058, Belgium, Brussels, Liutte 27, BE</li>
										<li><strong>E-mail:</strong>ericasmile@company.com</li>
										<li><strong>Phone:</strong>+1 256 254 84 56</li>
									</ul>
									<div class="social-icons">
										<a title="" href="#"><i class="fa fa-facebook"></i></a>
										<a title="" href="#"><i class="fa fa-linkedin"></i></a>
										<a title="" href="#"><i class="fa fa-twitter"></i></a>
										<a title="" href="#"><i class="fa fa-skype"></i></a>
									</div>
								</div><!-- Member Detail -->
							</div>
						</div><!-- Member Introduction -->
						
						<div class="staff-tabs">
							<div class="staff-tabs-selectors">
								<ul class="tabs">
									
									<li class="tab"><a class="active" href="#aboutme"><i class="fa fa-user"></i> About Me</a></li>
									
								</ul>
							</div>
							<div class="staff-tab-content">
								 
								 <div id="aboutme">
									
									<div class="all-skills">
										<div class="row">
											<div class="col s6 m6 16">
												<div class="staff-tab-content" style="box-shadow: -1px 2px 24px 0px rgba(127,127,127,1);color: #7F8080;">

												<div class="panel-header" style="text-align: center; color: cornflowerblue;">
													<h5 style="color: cornflowerblue;">
														<span>
															<i class="fa fa-stethoscope" aria-hidden="true"></i>Specialist in
														</span>
													</h5>
													<i class="fa fa-heart fa-2x" aria-hidden="true"></i>
												
													<h6><?php echo e($doctor->speciality); ?></h6><hr>
													<h6><?php echo e($doctor->degrees); ?></h6><hr>
													<p><?php echo e($doctor->doctor_short_summery); ?></p>
													</div>
												</div><hr>

												
 
												
												
											</div>
											<div class="col s6 m6 16">
												<div class="staff-tab-content" style="box-shadow: -1px 2px 24px 0px rgba(127,127,127,1);color: #7F8080;">

												<div class="panel-header" style="text-align: center; color: cornflowerblue;">
													
													<h5 style="color: cornflowerblue;">
														<span>
															<i class="fa fa-map-marker" aria-hidden="true"></i> 
															All Chambers
														</span>
													</h5>
													<i class="fa fa-heart fa-2x" aria-hidden="true"></i>
												
													<?php $__currentLoopData = $chambers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chamber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<hr>
															<h6>
																<i class="fa fa-anchor" aria-hidden="true"></i>
																<?php echo e($chamber->chamber_name); ?>

															</h6><hr>

														<address>
															<i class="fa fa-map-marker" aria-hidden="true"></i>
															<?php echo e($chamber->chamber_address); ?>

														</address>

														<p>
															<strong>
																<i class="fa fa-calendar" aria-hidden="true"></i>
																<?php echo e($chamber->app_day); ?>

															</strong><br>
															<strong>
																<i class="fa fa-clock-o" aria-hidden="true"></i> 
																<?php echo e($chamber->app_time); ?>

															</strong><br>
															<strong>
																<i class="fa fa-phone" aria-hidden="true"></i>
																<?php echo e($chamber->chamber_phone); ?>

															</strong>
														</p>

														<p>
															<i class="fa fa-hospital-o" aria-hidden="true"></i>
															New Patient: <?php echo e($chamber->new_patient); ?>.tk <br>
															<i class="fa fa-refresh" aria-hidden="true"></i>
															Returning Patient: <?php echo e($chamber->returning_patient); ?>.tk<br>
															<i class="fa fa-file-text-o" aria-hidden="true"></i>
															Followup Report: <?php echo e($chamber->followup_report); ?>.tk
														</p>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											    </div>
											  </div>

												
											</div>
											
										</div>
									</div><!-- All Skills -->
								</div>
								 
							</div>
					</div><!-- Staff Detail -->
				</div>
			</div>
		</div>
	</div>
</section>


<section>
    <div class="block grayish">
        <div class="parallax-container"><div class="parallax"><img src="<?php echo e(asset('images/resource/parallax2.jpg')); ?>" alt="" /></div></div>
        <div class="container">
            <div class="row">
                
                    <div class="classic-title">
                        <h2><span>Our Experienced</span>Medical Staff</h2>
                    </div>
                    <div class="staff-carousel">
                        <div class="staff-slide">
                            <div class="row">                               
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>Jacobson Ad</a></strong>
                                            <i>Orthopaedics</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>John Smith</a></strong>
                                            <i>Cardiologist</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>Jaka Alex</a></strong>
                                            <i>Neurologist</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>Alex Hashan</a></strong>
                                            <i>Haematologist</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                            </div>
                        </div><!-- Staff Slide -->
                        <div class="staff-slide">
                            <div class="row">
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>Jaka Alex</a></strong>
                                            <i>Neurologist</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>Alex Hashan</a></strong>
                                            <i>Haematologist</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>John Smith</a></strong>
                                            <i>Cardiologist</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                                <div class="col l6 m6 s6">
                                    <div class="staff-member">
                                        <div class="member-img"><img src="<?php echo e(asset('images/resource/doctor1.jpg')); ?>" alt="" /></div>
                                        <div class="doctor-intro">
                                            <strong><a href="staff-detail.html" title=""><span>Dr.</span>Jacobson Ad</a></strong>
                                            <i>Orthopaedics</i>
                                        </div>
                                    </div><!-- Staff Member -->
                                </div>
                            </div>
                        </div><!-- Staff Slide -->
                    </div><!-- Staff Carousel -->           
                </div>
            </div>
        </div>
  
</section>

 


<?php $__env->stopSection(); ?>

<?php $__env->startSection('jslink'); ?>
	

    <script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>


  <script type="text/javascript">

        jQuery(document).ready(function() {

            /* ============  Carousel ================*/
            $('.staff-carousel').owlCarousel({
                autoplay:true,
                autoplayTimeout:2500,
                smartSpeed:2000,
                autoplayHoverPause:true,
                loop:true,
                dots:false,
                nav:true,
                margin:0,
                mouseDrag:true,
                singleItem:false,
                items:2,
                autoHeight:true

            });     

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>